/*
 * A hello world
 */

#include <iostream>

int main(int argc, char **argv) {
	std::cout << "Wow! It works!" << std::endl;
}
